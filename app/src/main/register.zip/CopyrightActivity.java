package com.example.register;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.kch.proj_manager_v3.R;

public class CopyrightActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_copyright);
    }
}
